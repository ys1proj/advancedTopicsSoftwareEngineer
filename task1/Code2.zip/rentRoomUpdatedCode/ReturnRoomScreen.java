import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReturnRoomScreen extends JFrame implements ActionListener {
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private House selectedHouse;
	    private JComboBox<String> roomComboBox;
	    private JButton returnButton;
	    private JButton returnScreenButton;

	    public ReturnRoomScreen(House selectedHouse) {
	        this.selectedHouse = selectedHouse;

	        setTitle("Return Room");
	        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setSize(300, 150);
	        setLayout(new GridLayout(3, 2));

	        JLabel roomLabel = new JLabel("Select the Room:");
	        add(roomLabel);

	        roomComboBox = new JComboBox<>();
	        for (Room room : selectedHouse.getRooms()) {
	            roomComboBox.addItem("Room ID: " + room.getRoomNumber());
	        }
	        add(roomComboBox);

	        returnButton = new JButton("Return Room");
	        returnButton.addActionListener(this);
	        add(returnButton);

	        returnScreenButton = new JButton("Close");
	        returnScreenButton.addActionListener(this);
	        add(returnScreenButton);

	        setVisible(true);
	    }

	    @Override
	    public void actionPerformed(ActionEvent e) {
	        if (e.getSource() == returnButton) {
	            int selectedRoomIndex = roomComboBox.getSelectedIndex();
	            Room selectedRoom = selectedHouse.getRooms().get(selectedRoomIndex);
	            if(selectedRoom.getRenter()!=null) {
	               Customer selectedCustomer = selectedRoom.getRenter();
	               selectedRoom.setRenter(null);
	               selectedRoom.setAvailable(true);
	               selectedRoom.setStatus(RentStatus.freerooms);
	               JOptionPane.showMessageDialog(this, "Room returned successfully by " + selectedCustomer.getName());
	            }
	            else {
	                   JOptionPane.showMessageDialog(this, "Room is not currently rented");
	            }
	        }
	        if (e.getSource() == returnScreenButton) {
	            dispose();
	        }
	    }
}
