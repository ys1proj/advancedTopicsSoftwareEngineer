public enum FacilityStatus {
	asnew,
	good,
	worn
}