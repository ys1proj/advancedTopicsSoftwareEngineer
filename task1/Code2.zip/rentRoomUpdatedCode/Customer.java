public class Customer {

	private String name;
	private String mail;

	public Customer(String name, String mail) {
		super();
		this.name = name;
		this.mail = mail;
	}

	public String getName() {
	    return this.name;
	}

	public void setName(String name) {
	     this.name = name;
	}
	
	public String getMail() { 
	    return this.mail;
	}
	
	public void setMail(String ml) {
	     this.mail = ml;
	}

}