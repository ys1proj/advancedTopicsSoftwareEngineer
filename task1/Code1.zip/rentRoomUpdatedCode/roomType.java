public enum roomType {
	;

	private int single;
	private int duo;
	private int family;

}