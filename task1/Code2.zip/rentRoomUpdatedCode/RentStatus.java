public enum RentStatus {
	free,
	rented,
	freerooms
}