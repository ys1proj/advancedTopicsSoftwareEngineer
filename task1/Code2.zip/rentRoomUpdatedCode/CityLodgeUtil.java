import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CityLodgeUtil {

    public static final String STRING_FORMAT = "%-25s%s%n";

    public static final String ERROR = "Error";
    public static final String SUCCESS = "Success";

    /**
     * This method is used to format the details
     *
     * @param name   a String containing item name
     * @param detail a String containing item value
     * @return a formatted item and its value
     */
    public static String tabFormat(String name, String detail) {
        return String.format(STRING_FORMAT, name, detail);
    }

    /**
     * This method displays an error message dialog.
     *
     * @param message the error message to display
     */
    public static void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(null, message, ERROR, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * This method displays a success message dialog.
     *
     * @param message the success message to display
     */
    public static void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(null, message, SUCCESS, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * This method validates if a string can be parsed into an integer.
     *
     * @param input the string to validate
     * @return true if the string can be parsed into an integer, false otherwise
     */
    public static boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * This method converts a string date to a LocalDate object using the specified pattern.
     *
     * @param date    the string date to convert
     * @param pattern the pattern of the date string
     * @return a LocalDate object representing the converted date
     */
    public static LocalDate convertToDate(String date, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDate.parse(date, formatter);
    }
}