import java.util.*;

public class House {

	private int houseID;
	private int beds;
	private int numOfRooms;
	private double area;
	private String address;
	private double pricePerYear;
	private boolean petsAllowed;
	private HouseType type;
	private RentStatus status;
	private Collection<Facility> facilities;


	/**
	 * 
	 * @param houseID
	 * @param beds
	 * @param numOfRooms
	 * @param area
	 * @param address
	 * @param price
	 * @param pets
	 * @param type
	 * @param facilities
	 * @param rooms
	 */
	public House(int houseID, int beds, int numOfRooms, double area, String address, double price, boolean pets, HouseType type, java.util.ArrayList<Facility> facilities, java.util.ArrayList<Room> rooms) {
		this.beds = beds;
		this.rooms = rooms;
		this.numOfRooms = numOfRooms;
		this.area = area;
		this.address = address;
		this.pricePerYear = price;
		this.petsAllowed = pets;
		this.type = type;
		this.facilities = facilities;
		this.renter = null;
		this.status = RentStatus.free;
		this.houseID = idCounter++;
	}

	public Customer getRenter() {
		return renter;
	}

	public void setRenter(Customer renter) {
		this.renter = renter;
	}

	public int getBeds() {
		return beds;
	}

	public void setBeds(int beds) {
		this.beds = beds;
	}

	public int getNumOfRooms() {
		return numOfRooms;
	}

	public void setNumOfRooms(int numOfRooms) {
		this.numOfRooms = numOfRooms;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getHouseID() {
		return houseID;
	}

	public void setHouseID(int houseID) {
		this.houseID = houseID;
	}

    public List<Room> getRooms() {
        return rooms;
    }

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}

	/**
	 * 
	 * @param newPrice
	 */
	public void changePrice(double newPrice) {
		this.pricePerYear = newPrice;
	}

	/**
	 * 
	 * @param newFacility
	 */
	public void addFacility (Facility newFacility) {
		this.facilities.add(newFacility);
	}

	/**
	 * 
	 * @param aFacility
	 */
	public void removeFacility (Facility aFacility) {
		Iterator<Facility> itr = this.facilities.iterator(); 
        while (itr.hasNext()) { 
        	Facility f = (Facility)itr.next(); 
            if (f.equals(aFacility)) 
                itr.remove(); 
        } 
	}

	public Collection<Facility> getFacilities() {
		return facilities;
	}

	public void setFacilities(Collection<Facility> facilities) {
		this.facilities = facilities;
	}

	public boolean checkAvailability() {
		return (status==RentStatus.free);
	}

	/**
	 * 
	 * @param c
	 */
	public boolean rent(Customer c) {
		if (checkAvailability()) {
			renter=c;
			status = RentStatus.rented;
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 
	 * @param c
	 */
	public boolean endRent(Customer c) {
		if ((renter!=null) && (renter.equals(c))) {
            renter = null;
            status = RentStatus.free;
            return true;        
        }
		else
			return false;
	}
	
	
	public HouseType getType() {
		return type;
	}

	public void setType(HouseType type) {
		this.type = type;
	}

	private List<Room> rooms;
	private Customer renter;
	private static int idCounter = 0;
	 

	public RentStatus getStatus() {
		return this.status;
	}

	public void setStatus(RentStatus status) {
		this.status = status;
	}

	public double getPricePerYear() {
		return pricePerYear;
	}

	public void setPricePerYear(double pricePerYear) {
		this.pricePerYear = pricePerYear;
	}

	public boolean isPetsAllowed() {
		return petsAllowed;
	}

	public void setPetsAllowed(boolean petsAllowed) {
		this.petsAllowed = petsAllowed;
	}


}