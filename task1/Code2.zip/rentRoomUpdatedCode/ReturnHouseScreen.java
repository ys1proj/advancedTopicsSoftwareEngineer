import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReturnHouseScreen extends JFrame implements ActionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private House selectedHouse;
    private JComboBox<String> customerComboBox;
    private ArrayList<Customer> customers;
    private JButton returnButton;
    private JButton returnScreenButton;

    public ReturnHouseScreen(House selectedHouse, ArrayList<Customer> customers) {
        this.selectedHouse = selectedHouse;
        this.customers = customers;

        setTitle("Return House");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 150);
        setLayout(new GridLayout(2, 2));

        JLabel customerLabel = new JLabel("Select the Customer:");
        add(customerLabel);

        customerComboBox = new JComboBox<>();
        for (Customer customer : customers) {
            customerComboBox.addItem(customer.getName());
        }
        add(customerComboBox);

        returnButton = new JButton("Return House");
        returnButton.addActionListener(this);
        add(returnButton);

        returnScreenButton = new JButton("Close");
        returnScreenButton.addActionListener(this);
        add(returnScreenButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == returnButton) {
            String selectedCustomerName = (String) customerComboBox.getSelectedItem();
            Customer selectedCustomer = getCustomerByName(selectedCustomerName);

            if (selectedCustomer != null) {
                if (selectedHouse.endRent(selectedCustomer)) {
                    JOptionPane.showMessageDialog(this, "House returned successfully by " + selectedCustomer.getName());
                } else {
                    JOptionPane.showMessageDialog(this, "House is not currently rented by " + selectedCustomer.getName());
                }
            }
        }
        if (e.getSource() == returnScreenButton) {
            dispose();
        }
    }

    // Method to get Customer object by name
    private Customer getCustomerByName(String name) {
        for (Customer customer : customers) {
            if (customer.getName().equals(name)) {
                return customer;
            }
        }
        return null; // Customer not found
    }
}