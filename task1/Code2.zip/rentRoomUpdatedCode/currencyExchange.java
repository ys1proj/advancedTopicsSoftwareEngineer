import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

public class currencyExchange extends JFrame implements ActionListener {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String[] currencies = {"ILS", "CAD", "AUS", "Euro", "USD"}; //Adding the relevant currencies
    private JComboBox<String> comboBoxFrom;
    private JComboBox<String> comboBoxTo;
    private JSpinner spinnerAmount;
    private JTextField textFieldResult;
    private JButton buttonConvert;

    public currencyExchange() {
    	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Currency Converter");
        setSize(450, 300);
        setLayout(null); // Using absolute positioning


        JLabel labelAmount = new JLabel("Amount:");
        labelAmount.setBounds(26, 71, 60, 20);
        add(labelAmount);
        spinnerAmount = new JSpinner(new SpinnerNumberModel(0.0, 0.0, Double.MAX_VALUE, 0.01));
        spinnerAmount.setBounds(90, 71, 74, 20);
        add(spinnerAmount);
        
        // Create and add components
        comboBoxFrom = new JComboBox<>(currencies);
        comboBoxFrom.setBounds(180, 71, 117, 20);
        add(comboBoxFrom);
        
        JLabel labelTo = new JLabel("To");
        labelTo.setBounds(305, 71, 50, 20); // Adjusted position
        add(labelTo);
        comboBoxTo = new JComboBox<>(currencies);
        comboBoxTo.setBounds(327, 71, 104, 20);
        add(comboBoxTo);

        JLabel labelResult = new JLabel("Result:");
        labelResult.setBounds(110, 189, 50, 20);
        add(labelResult);
        textFieldResult = new JTextField();
        textFieldResult.setEditable(false);
        textFieldResult.setBounds(160, 189, 86, 20);
        add(textFieldResult);

        buttonConvert = new JButton("Convert");
        buttonConvert.setBounds(146, 131, 104, 23);
        add(buttonConvert);
        buttonConvert.addActionListener(this);
        
		JLabel lblCurrencyConverter = new JLabel("Currency Converter");
		lblCurrencyConverter.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblCurrencyConverter.setBounds(110, 11, 214, 29);
		this.add(lblCurrencyConverter);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttonConvert) {
            int fromIndex = comboBoxFrom.getSelectedIndex();
            int toIndex = comboBoxTo.getSelectedIndex();
            double amount = (double) spinnerAmount.getValue();

            currency c1 = currency.Identify(fromIndex);
            currency c2 = currency.Identify(toIndex);

            double result = currency.convert(amount, c1, c2);
            textFieldResult.setText(String.format("%.2f", result));
        }
    }
}