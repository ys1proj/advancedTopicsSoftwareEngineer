import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;


public class RoomRentalScreen extends JFrame implements ActionListener, ItemListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<House> houses;
    private ArrayList<Customer> customers;
    private JComboBox<String> houseComboBox;
    private JComboBox<String> roomComboBox;
    private JComboBox<String> customerComboBox;
    private JButton rentButton;
    private JLabel priceLabel;
    private JLabel sizeLabel;
    private JLabel roomTypeLabel;

    public RoomRentalScreen(ArrayList<House> houses, ArrayList<Customer> customers) {
        this.houses = houses;
        this.customers = customers;

        setTitle("Room Rental");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 200);
        setLayout(new GridLayout(5, 1));

        add(new JLabel("Select House:"));
        houseComboBox = new JComboBox<>();
        for (House house : houses) {
            houseComboBox.addItem("House ID: " + house.getHouseID());
        }
        houseComboBox.addItemListener(this); // Add ItemListener
        add(houseComboBox);

        roomComboBox = new JComboBox<>();
        add(new JLabel("Select Room:"));
        roomComboBox.addItemListener(this); // Add ItemListener
        add(roomComboBox);

        customerComboBox = new JComboBox<>();
        add(new JLabel("Select Customer:"));
        for (Customer customer : customers) {
            customerComboBox.addItem(customer.getName());
        }
        add(customerComboBox);

        rentButton = new JButton("Rent Room");
        rentButton.addActionListener(this);
        add(rentButton);

        priceLabel = new JLabel();
        add(priceLabel);

        sizeLabel = new JLabel();
        add(sizeLabel);

        roomTypeLabel = new JLabel();
        add(roomTypeLabel);

        setVisible(true);
        
     // Manually trigger itemStateChanged to display house details for the initially selected house
        itemStateChanged(new ItemEvent(houseComboBox, ItemEvent.ITEM_STATE_CHANGED, null, ItemEvent.SELECTED));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == rentButton) {
            int selectedHouseIndex = houseComboBox.getSelectedIndex();
            int selectedRoomIndex = roomComboBox.getSelectedIndex();
            int selectedCustomerIndex = customerComboBox.getSelectedIndex();

            if (selectedHouseIndex != -1 && selectedRoomIndex != -1 && selectedCustomerIndex != -1) {
                House selectedHouse = houses.get(selectedHouseIndex);
                Room selectedRoom = selectedHouse.getRooms().get(selectedRoomIndex);
                Customer selectedCustomer = customers.get(selectedCustomerIndex);

                if (selectedRoom.isAvailable()) {
                    selectedRoom.rentRoomTo(selectedCustomer);
                    LocalDate currentDate = LocalDate.now();
                    JOptionPane.showMessageDialog(this, "Room rented to " + selectedCustomer.getName() + " on " + currentDate, "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Room is already rented", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a house, room, and customer", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            if (e.getSource() == houseComboBox) {
                updateRoomComboBox();
            } else if (e.getSource() == roomComboBox) {
                updateRoomDetails();
            }
        }
    }

    private void updateRoomComboBox() {
        int selectedHouseIndex = houseComboBox.getSelectedIndex();
        if (selectedHouseIndex >= 0 && selectedHouseIndex < houses.size()) {
            House selectedHouse = houses.get(selectedHouseIndex);
            roomComboBox.removeAllItems();
            for (Room room : selectedHouse.getRooms()) {
                roomComboBox.addItem("Room: " + room.getRoomNumber());
            }
            if (roomComboBox.getItemCount() > 0) {
                roomComboBox.setSelectedIndex(0); // Select first room by default
                updateRoomDetails();
            }
        }
    }

    private void updateRoomDetails() {
        int selectedHouseIndex = houseComboBox.getSelectedIndex();
        int selectedRoomIndex = roomComboBox.getSelectedIndex();
        if (selectedHouseIndex >= 0 && selectedRoomIndex >= 0) {
            House selectedHouse = houses.get(selectedHouseIndex);
            Room selectedRoom = selectedHouse.getRooms().get(selectedRoomIndex);
            priceLabel.setText("Price per Night: $" + selectedRoom.getPricePerNight());
            sizeLabel.setText("Size: " + selectedRoom.getSize() + " sqm");
            roomTypeLabel.setText("Room Type: " + selectedRoom.getRoomType());
        }
    }
}