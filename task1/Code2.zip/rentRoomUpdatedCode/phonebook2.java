
import java.util.Scanner;
import java.util.Vector;
import java.util.HashSet;
import java.util.Iterator;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

/*
 * This is the phonebook2 project we used from https://github.com/tydankim/Phone-Book
 */
class PhoneBook2 {	
	public static void main(String[] args) {
//		PhoneBookManager manager = PhoneBookManager.createManagerInst();
		MainFrame winFrame = new MainFrame("Phone Book by Daniel Kim");
	}
}


class MainFrame extends JFrame	{
	
//	=============================		NEW COMPONENTS		======================================
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JComboBox<String> houseComboBox = new JComboBox<String>();
	JLabel numberOfRoomsJLabel = new JLabel("house.getRooms()");
	JLabel houseAreaJLabel = new JLabel("Area: + house.getArea()");
	JLabel houseAddressJLabel = new JLabel("Address: + house.getAddress()");
	JLabel petsAllowedJLabel = new JLabel("Pets allowed: + house.isPetsAllowed() ? \"Yes\" : \"No\" ");
	JLabel houseTypeJLabel = new JLabel("House Type: + house.getType().toString()");
	JLabel roomCostLabel = new JLabel("Price Per Year: + house.getPricePerYear()");
	
	
	
//	==============================		Original COMPONENTS		======================================
	
	JButton delBtn = new JButton("DEL");

//	JTextArea textArea = new JTextArea(10, 25);

	public MainFrame(String title)
	{
		super(title);
		setBounds(100, 200, 1450, 950);
		setSize(1100,650);
		setLayout(new GridLayout(0,2,0,0));
		Border border = BorderFactory.createEtchedBorder();



// =============================== TOP PART =================================================================		
		
		// TOP PART
		
		houseComboBox.addItem("house 0");
		houseComboBox.addItem("house 1");
		
		
		
		// House Panel Design
		Border houseBorder = BorderFactory.createTitledBorder(border, "House");
		JPanel housePanel = new JPanel();
		housePanel.setBorder(houseBorder);
		
		// House, Client combobox row panel.
		JPanel houseCLientFlowPanel = new JPanel(new GridLayout(1,0,5,5));
		
		
		// House comboBox design
		housePanel.setLayout(new GridLayout(7,0,5,5));
		
		
		// client comboBox design
		JComboBox<String> clientComboBox = new JComboBox<String>();
		clientComboBox.addItem("client.getName");
		Border clientBorder = BorderFactory.createTitledBorder(border, "Client");
		JPanel clientPanel = new JPanel();
		clientPanel.setLayout(new GridLayout(1,1,0,0));
		clientPanel.add(clientComboBox);
		
//		JPanel clientComboBoxPanel = new JPanel(new FlowLayout());
//		clientComboBoxPanel.add(clientPanel);
//		housePanel.add(clientComboBoxPanel);
		
		
		// House Combobox Design
		Border houseComboBoxBorder = BorderFactory.createTitledBorder(border, "House");
		JPanel houseComboBoxPanel = new JPanel();
		houseComboBoxPanel.setBorder(houseComboBoxBorder);
		houseComboBoxPanel.setLayout(new GridLayout(1,1,0,0));
		houseComboBoxPanel.add(houseComboBox);
		
		
		// Adding a Panel with both comboboxes as first row
		houseCLientFlowPanel.add(houseComboBoxPanel);
		houseCLientFlowPanel.add(clientComboBox);
		
		clientPanel.setBorder(clientBorder);
		
		
		housePanel.add(houseCLientFlowPanel);
		
		
		housePanel.add(numberOfRoomsJLabel);
		housePanel.add(houseAreaJLabel);
		housePanel.add(houseAddressJLabel);
		housePanel.add(petsAllowedJLabel);
		housePanel.add(houseTypeJLabel);
		housePanel.add(roomCostLabel);
		
		
		
// ===============================================================================================================
		

		
		
		
		
// ============================= MIDDLE PART ==============================================================
		
		// MIDDLE PART
		
		
		// NEW COMPONENTS
		JComboBox<String> roomNumberComboBox = new JComboBox<String>();
		roomNumberComboBox.addItem("room.getNumber()");
		JPanel roomComboBoxPanel = new JPanel();
		roomComboBoxPanel.add(roomNumberComboBox);
		
		JLabel roomType = new JLabel("room.getRoomType.toString()");
		JLabel size = new JLabel("room.getSize()");
		JLabel pricePerNight = new JLabel("room.getPricePerNight()");
		JLabel isAvailable = new JLabel("room.isAvailable()");
		JLabel status = new JLabel("room.getStatus.toString()");
		Border roomBorder=BorderFactory.createTitledBorder(border, "Room");
		JPanel roomPanel = new JPanel();
		
		roomPanel.setBorder(roomBorder);
//		roomPanel.setLayout(new FlowLayout());
		roomPanel.setLayout(new GridLayout(6,0,1,1));
//		roomPanel.add(rbtn1);
//		roomPanel.add(rbtn2);
//		roomPanel.add(rbtn3);
//		roomPanel.add(addBtn);
		
		
		
		
//		Border addBorder=BorderFactory.createTitledBorder(border, "Add");
//		Border addBorder=BorderFactory.createTitledBorder(border, "Room");
//		JPanel addPanel = new JPanel();
//		addPanel.setBorder(addBorder);
//		addPanel.setLayout(new FlowLayout());
//		addPanel.setLayout(new GridLayout(1,1,3,3));
		
		roomPanel.add( roomComboBoxPanel );
		roomPanel.add( roomType );
		roomPanel.add( size );
		roomPanel.add( pricePerNight );
		roomPanel.add( isAvailable );
		roomPanel.add( status );
		
		
//		JPanel addInputPanel = new JPanel();
//		addInputPanel.setLayout(new GridLayout(1,0,5,5));
//		buttonGroup.add(rbtn1);
//		buttonGroup.add(rbtn2);
//		buttonGroup.add(rbtn3);

//		addPanel.add(rbtn1);
//		addPanel.add(rbtn2);
//		addPanel.add(rbtn3);
//		addPanel.add(addBtn);

		
//		addInputPanel.add(nameLabel);
//		addInputPanel.add(nameField);
//		addInputPanel.add(phoneLabel);
//		addInputPanel.add(phoneField);
//		addInputPanel.add(majorLabel);
//		addInputPanel.add(majorField);
//		addInputPanel.add(yearLabel);
//		addInputPanel.add(yearField);
		
//		addPanel.add(nameLabel);
//		addPanel.add(nameField);
//		addPanel.add(phoneLabel);
//		addPanel.add(phoneField);
//		addPanel.add(majorLabel);
//		addPanel.add(majorField);
//		addPanel.add(yearLabel);
//		addPanel.add(yearField);
		
		

//		majorLabel.setVisible(false);
//		majorField.setVisible(false);
//		yearLabel.setVisible(false);
//		yearField.setVisible(false);
		
//		majorLabel.setVisible(true);
//		majorField.setVisible(true);
//		yearLabel.setVisible(true);
//		yearField.setVisible(true);

//		rbtn1.setSelected(true);
//		addPanel.add(addInputPanel);

//		rbtn1.addItemListener(
//				new ItemListener()
//				{
//					public void itemStateChanged(ItemEvent e)
//					{
//						if(e.getStateChange() == ItemEvent.SELECTED)
//						{
//							majorLabel.setVisible(false);
//							majorField.setVisible(false);
//							yearLabel.setVisible(false);
//							yearField.setVisible(false);
//							majorField.setText("");
//							yearField.setText("");
							
//							majorLabel.setVisible(true);
//							majorField.setVisible(true);
//							yearLabel.setVisible(true);
//							yearField.setVisible(true);
//						}
//					}
//				}
//				);

//		rbtn2.addItemListener(
//				new ItemListener()
//				{
//					public void itemStateChanged(ItemEvent e)
//					{
//						if(e.getStateChange() == ItemEvent.SELECTED)
//						{
//							majorLabel.setVisible(true);
//							majorLabel.setText("MAJOR");
//							majorField.setVisible(true);
//							yearLabel.setVisible(true);
//							yearField.setVisible(true);
//						}
//					}
//				}
//				);

//		rbtn3.addItemListener(
//				new ItemListener()
//				{
//					public void itemStateChanged(ItemEvent e)
//					{
//						if(e.getStateChange() == ItemEvent.SELECTED)
//						{
//							majorLabel.setVisible(true);
//							majorLabel.setText("COMPANY");
//							majorField.setVisible(true);
//							yearLabel.setVisible(false);
//							yearField.setVisible(false);
//							yearField.setText("");
//						}
//					}
//				}
//				);
		
// ===============================================================================================================		
		
		
		
		
// =============================== Bottom Section =========================================================		
		
		
		// ======================	NEW COMPONENTS	========================
		
//		JComboBox<String> clientComboBox = new JComboBox<String>();
//		clientComboBox.addItem("client.getName");
		
		// =======================	Original COMPONENTS	========================
		
		// Bottom section
//		Border delBorder = BorderFactory.createTitledBorder(border, "Client");
//		JPanel delPanel = new JPanel();
//		JPanel emptyPanel = new JPanel(new FlowLayout());
//		delPanel.setBorder(delBorder);
//		delPanel.setLayout(new GridLayout(2,1,0,0));
//		delPanel.add(clientComboBox);
//		emptyPanel.add(delPanel);
//		delPanel.setLayout(new FlowLayout());
//		delPanel.add(delField);
//		delPanel.add(delBtn);


// ===============================================================================================================
		
		
		
		
// =============================== SIDE PANEL =========================================================
		
		// SIDE PANEL
		JPanel facilitiesPanel = new JPanel();
		JScrollPane facilitesListArea = new JScrollPane(facilitiesPanel);
		Border facilityBorder = BorderFactory.createTitledBorder(border, "Facilities");
		facilitesListArea.setBorder(facilityBorder);
		
		
		JPanel actionPanel = new JPanel();
		actionPanel.setLayout(new BorderLayout());
		actionPanel.add(housePanel, BorderLayout.NORTH);
//		actionPanel.add(addPanel, BorderLayout.CENTER);

//		actionPanel.add(roomPanel, BorderLayout.SOUTH);
		actionPanel.add(roomPanel, BorderLayout.CENTER);
		
//		actionPanel.add(facilitesListArea, BorderLayout.EAST);
		add(actionPanel);
		add(facilitesListArea);

//		srchBtn.addActionListener(new SearchEventHandler(srchField, textArea));
//		addBtn.addActionListener(new AddEventHandler(nameField, phoneField, majorField, yearField, textArea));
//		delBtn.addActionListener(new DeleteEventHandler(delField, textArea));

		setVisible(true);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);	
	}
}














//	=======================================================================================================	\\
//=======================================================================================================	\\
//=======================================================================================================	\\




//========================================= 	Action Listeners		=================================	\\




//=======================================================================================================	\\
//=======================================================================================================	\\
//=======================================================================================================	\\







class SearchEventHandler implements ActionListener {
	JTextField searchField;
	JTextArea textArea;

//	public SearchEventHandler(JTextField field, JTextArea area) {
//		searchField=field;
//		textArea=area;
//	}

	public void actionPerformed(ActionEvent e) {
//		String name = searchField.getText();
//		PhoneBookManager manager=PhoneBookManager.createManagerInst();
//		String srchResult = manager.searchData(name);
//		if(srchResult == null)
//			textArea.append("Search Failed: info does not exist.\n");
//		else {
//			textArea.append("Search Completed:\n");
//			textArea.append(srchResult);
//			textArea.append("\n");
//		}
	}
}
class AddEventHandler implements ActionListener {
	JTextField name;
	JTextField phone;
	JTextField major;
	JTextField year;
	JTextField company;
	JTextArea text;
	Vector<String> inputList = new Vector<String>();

	boolean isAdded;
	
	public void actionPerformed(ActionEvent e)	{
//		PhoneBookManager manager = PhoneBookManager.createManagerInst();
//		if(major.getText().equals("") == false && year.getText().equals("") == true) {
//			company = major;
//			info = new PhoneCompanyInfo(name.getText(), phone.getText(), company.getText());
//			isAdded = manager.infoStorage.add(info);
//		}		
//		else if(major.getText().equals("") == false && year.getText().equals("") == false) {
//			info = new PhoneUnivInfo(name.getText(), phone.getText(), major.getText(), Integer.parseInt(year.getText()));
//			isAdded = manager.infoStorage.add(info);
//		}
//		else {
//			info = new PhoneInfo(name.getText(), phone.getText());
//			isAdded = manager.infoStorage.add(info);
//		}
		if(isAdded)		text.append("Update Completed.\n");
			else		text.append("Update Failed: info already exist.\n");		
	}
}
class DeleteEventHandler implements ActionListener {
	JTextField delField;
	JTextArea textArea;

	public DeleteEventHandler(JTextField field, JTextArea area)	{
		delField = field;
		textArea = area;
	}

	public void actionPerformed(ActionEvent e) {
		String name = delField.getText();
//		PhoneBookManager manager = PhoneBookManager.createManagerInst();
//		boolean isDeleted = manager.deleteData(name);
		
//		if(isDeleted)	textArea.append("Remove Completed.\n");
//			else		textArea.append("Remove Failed: info does not exist.\n");	
	}
}









