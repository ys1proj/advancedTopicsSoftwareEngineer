import java.util.ArrayList;
import java.awt.*;        // Using AWT container and component classes
import java.awt.event.*;  // Using AWT event classes and listener interfaces
import javax.swing.*;
public class MainTest extends JFrame implements ActionListener{

 	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton currencyExchangeButton;
    private JButton houseRentalButton;
 	private JButton roomRentalButton;
    private JButton returnHouseButton;
    private JButton returnRoomButton;

    private currencyExchange currencyExchangeScreen;
    private ArrayList<House> houses;
    private ArrayList<Customer> customers;
    private House selectedHouse;

    public MainTest(ArrayList<House> houses, ArrayList<Customer> customers) {
        this.houses = houses;
        this.customers = customers;

        setTitle("Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLayout(new GridLayout(4, 1));

        currencyExchangeButton = new JButton("Currency Exchange");
        currencyExchangeButton.addActionListener(this);
        currencyExchangeButton.setBackground(Color.WHITE); // Set background color
        add(currencyExchangeButton);

        houseRentalButton = new JButton("House Rental");
        houseRentalButton.addActionListener(this);
        houseRentalButton.setBackground(Color.WHITE); // Set background color
        add(houseRentalButton);

        roomRentalButton = new JButton("Room Rental");
        roomRentalButton.addActionListener(this);
        roomRentalButton.setBackground(Color.WHITE); // Set background color
        add(roomRentalButton);

        returnHouseButton = new JButton("Return House");
        returnHouseButton.addActionListener(this);
        returnHouseButton.setBackground(Color.WHITE); // Set background color
        add(returnHouseButton);
        
        returnRoomButton = new JButton("Return Room"); // Initialize the button
        returnRoomButton.addActionListener(this); // Add ActionListener to the button
        returnRoomButton.setBackground(Color.WHITE); // Set background color
        add(returnRoomButton); // Add the button to the frame

        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
    	
    	if (e.getSource() == currencyExchangeButton)	currencyExchangeScreen();
    	else if (e.getSource() == houseRentalButton)	HouseRentalScreen(houses, customers);
        else if (e.getSource() == roomRentalButton)		RoomRentalScreen(houses, customers);
        else if (e.getSource() == returnHouseButton)	ReturnHouseScreen(customers);
        else if (e.getSource() == returnRoomButton)		ReturnRoomScreen(selectedHouse);
    }
    
    private void currencyExchangeScreen() {
//    	if (currencyExchangeScreen == null)
    		currencyExchangeScreen = new currencyExchange();
		currencyExchangeScreen.setVisible(true); // Make it visible immediately
    }
    
    private void HouseRentalScreen(ArrayList<House> houses, ArrayList<Customer> customers) {
    	new HouseRentalScreen(houses, customers);
    }
    
    private void RoomRentalScreen(ArrayList<House> houses, ArrayList<Customer> customers) {
    	new RoomRentalScreen(houses, customers);
    }
    
    
    private void ReturnHouseScreen(ArrayList<Customer> customers) {
    	
        String[] houseOptions = new String[houses.size()];
        
        for (int i = 0; i < houses.size(); i++)
            houseOptions[i] = "House ID: " + houses.get(i).getHouseID();
        
        String selectedHouseID = (String) JOptionPane.showInputDialog(this, "Select the House to return:", "Return House", JOptionPane.QUESTION_MESSAGE, null, houseOptions, houseOptions[0]);
        
        if (selectedHouseID != null) {
        	
            int houseID = Integer.parseInt(selectedHouseID.split(": ")[1]);
            
            House selectedHouse = null;
            
            for (House house : houses)
                if (house.getHouseID() == houseID) {
                    selectedHouse = house;
                    break;
                }
            new ReturnHouseScreen(selectedHouse, customers);
        }
    }
    
    
    private void ReturnRoomScreen( House selectedHouse ) {
    	
    	String[] houseOptions = new String[houses.size()];
        
    	for (int i = 0; i < houses.size(); i++)
            houseOptions[i] = "House ID: " + houses.get(i).getHouseID();
    	
        String selectedHouseID = (String) JOptionPane.showInputDialog(this, "Select the House of Room to return:", "Return House", JOptionPane.QUESTION_MESSAGE, null, houseOptions, houseOptions[0]);
        
        if (selectedHouseID != null) {
            int houseID = Integer.parseInt(selectedHouseID.split(": ")[1]);
            
            selectedHouse = null;
            
            for (House house : houses)
                if (house.getHouseID() == houseID) {
                    selectedHouse = house;
                    break;
                }
            // Open the ReturnRoomScreen
            new ReturnRoomScreen(selectedHouse); // Pass the selected house
        }
    }
    
    public static void main(String[] args) {
    	 Facility facility1 = new Facility("Sofa", "2 seat sofa", FacilityStatus.asnew);
    	    Facility facility2 = new Facility("Table", "140 cm table", FacilityStatus.good);
    	    Facility facility3 = new Facility("Chair", "Black chair", FacilityStatus.good);
    	    Facility facility4 = new Facility("Bed", "Double Bed", FacilityStatus.worn);
    	    Facility facility5 = new Facility("Clock", "Alarm clock", FacilityStatus.asnew);

    	    ArrayList<Facility> facilities1 = new ArrayList<>();
    	    facilities1.add(facility2);
    	    facilities1.add(facility4);
    	    facilities1.add(facility5);
    	    House house1 = new House(0, 4, 3, 120, "str 1, Haifa", 5000, true, HouseType.apartment, facilities1, null);

    	    ArrayList<Room> rooms1 = new ArrayList<>();
    	    rooms1.add(new Room(roomType.single, 1, 25.0, 40.0, true, house1.getHouseID(), null, RentStatus.free));
    	    rooms1.add(new Room(roomType.duo, 2, 35.0, 50.0, true, house1.getHouseID(), null, RentStatus.free));
    	    house1.setRooms(rooms1);

    	    ArrayList<Facility> facilities2 = new ArrayList<>();
    	    facilities2.add(facility1);
    	    facilities2.add(facility3);
    	    facilities2.add(facility5);
    	    House house2 = new House(1, 7, 8, 250, "str 2, Tel Aviv", 10000, false, HouseType.house, facilities2, null);

    	    ArrayList<Room> rooms2 = new ArrayList<>();
    	    rooms2.add(new Room(roomType.single, 1, 20.0, 50.0, true, house2.getHouseID(), null, RentStatus.freerooms));
    	    rooms2.add(new Room(roomType.duo, 2, 30.0, 60.0, true, house2.getHouseID(), null, RentStatus.freerooms));
    	    rooms2.add(new Room(roomType.family, 3, 48.0, 75.0, true, house2.getHouseID(), null, RentStatus.freerooms));
    	    house2.setRooms(rooms2);

    	    ArrayList<Customer> customers = new ArrayList<>();
    	    for (int i = 1; i < 21; i++) {
    	        customers.add(new Customer("client" + i, "052" + (i * (i + 1) * (i + 2))));
    	    }

    	    ArrayList<House> houses = new ArrayList<>();
    	    houses.add(house1);
    	    houses.add(house2);

    	    new MainTest(houses, customers);

 	}
}
