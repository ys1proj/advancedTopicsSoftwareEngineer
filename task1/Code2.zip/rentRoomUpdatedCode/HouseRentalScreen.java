import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;


public class HouseRentalScreen extends JFrame implements ActionListener, ItemListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<House> houses;
    private ArrayList<Customer> customers;
    private JComboBox<String> houseComboBox;
    private JComboBox<String> customerComboBox;
    private JButton rentButton;
    private JButton showFacilitiesButton;
    private JLabel petsLabel; // Label to display whether pets are allowed
    private JLabel priceLabel; // Label to display the price per year
    private JLabel bedsLabel; // Label to display the number of beds
    private JLabel numOfRoomsLabel; // Label to display the number of rooms
    private JLabel areaLabel; // Label to display the area
    private JLabel addressLabel; // Label to display the address
    private JLabel typeLabel; // Label to display the house type

    public HouseRentalScreen(ArrayList<House> houses, ArrayList<Customer> customers) {
        this.houses = houses;
        this.customers = customers;

        setTitle("House Rental");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLayout(new GridLayout(9, 1));

        houseComboBox = new JComboBox<>();
        for (House house : houses) {
            houseComboBox.addItem("House ID: " + house.getHouseID());
        }
        houseComboBox.addItemListener(this); // Add item listener to update labels when house selection changes
        add(new JLabel("Select House:"));
        add(houseComboBox);

        customerComboBox = new JComboBox<>();
        for (Customer customer : customers) {
            customerComboBox.addItem(customer.getName());
        }
        add(new JLabel("Select Customer:"));
        add(customerComboBox);

        rentButton = new JButton("Rent House");
        rentButton.addActionListener(this);
        add(rentButton);

        showFacilitiesButton = new JButton("Show Facilities");
        showFacilitiesButton.addActionListener(this);
        add(showFacilitiesButton);

        petsLabel = new JLabel(); // Initialize pets label
        add(petsLabel);

        priceLabel = new JLabel(); // Initialize price label
        add(priceLabel);

        bedsLabel = new JLabel(); // Initialize beds label
        add(bedsLabel);

        numOfRoomsLabel = new JLabel(); // Initialize number of rooms label
        add(numOfRoomsLabel);

        areaLabel = new JLabel(); // Initialize area label
        add(areaLabel);

        addressLabel = new JLabel(); // Initialize address label
        add(addressLabel);

        typeLabel = new JLabel(); // Initialize type label
        add(typeLabel);

        setVisible(true);

        // Manually trigger itemStateChanged to display house details for the initially selected house
        itemStateChanged(new ItemEvent(houseComboBox, ItemEvent.ITEM_STATE_CHANGED, null, ItemEvent.SELECTED));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == rentButton) {
            int selectedHouseIndex = houseComboBox.getSelectedIndex();
            int selectedCustomerIndex = customerComboBox.getSelectedIndex();
            House selectedHouse = houses.get(selectedHouseIndex);
            Customer selectedCustomer = customers.get(selectedCustomerIndex);

            if (selectedHouse.rent(selectedCustomer)) {
                String message = CityLodgeUtil.tabFormat("House rented to:", selectedCustomer.getName());
                LocalDate currentDate = CityLodgeUtil.convertToDate(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), "dd/MM/yyyy");
                JOptionPane.showMessageDialog(this, message + " on " + currentDate, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "House is full and cannot be rented", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == showFacilitiesButton) {
            int selectedHouseIndex = houseComboBox.getSelectedIndex();
            House selectedHouse = houses.get(selectedHouseIndex);
            String facilitiesList = "Facilities for House ID " + selectedHouse.getHouseID() + ":\n";
            for (Facility facility : selectedHouse.getFacilities()) {
                facilitiesList += facility.getName() + "\n";
            }
            JOptionPane.showMessageDialog(this, facilitiesList, "Facilities", JOptionPane.PLAIN_MESSAGE);
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            int selectedHouseIndex = houseComboBox.getSelectedIndex();
            House selectedHouse = houses.get(selectedHouseIndex);
            petsLabel.setText("Pets Allowed: " + (selectedHouse.isPetsAllowed() ? "Yes" : "No"));
            priceLabel.setText("Price per Year: $" + selectedHouse.getPricePerYear());
            bedsLabel.setText("Beds: " + selectedHouse.getBeds());
            numOfRoomsLabel.setText("Number of Rooms: " + selectedHouse.getNumOfRooms());
            areaLabel.setText("Area: " + selectedHouse.getArea() + " sqm");
            addressLabel.setText("Address: " + selectedHouse.getAddress());
            typeLabel.setText("Type: " + selectedHouse.getType());
        }
    }
}

