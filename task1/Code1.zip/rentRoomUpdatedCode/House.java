import java.util.*;

public class House {

	private int houseID;
	private int beds;
	private int numOfRooms;
	private double area;
	private String address;
	private double pricePerYear;
	private boolean petsAllowed;
	private HouseType type;
	private RentStatus status;
	private Collection<Facility> facilities;
	private Collection<Room> rooms;
	private Customer renter;

	public RentStatus getStatus() {
		return this.status;
	}

	public void setStatus(RentStatus status) {
		this.status = status;
	}

	/**
	 * 
	 * @param houseID
	 * @param beds
	 * @param numOfRooms
	 * @param area
	 * @param address
	 * @param price
	 * @param pets
	 * @param type
	 * @param facilities
	 * @param rooms
	 */
	public House(int houseID, int beds, int numOfRooms, double area, String address, double price, boolean pets, HouseType type, java.util.ArrayList<Facility> facilities, java.util.ArrayList<Room> rooms) {
		this.beds = beds;
		this.rooms = rooms;
		this.area = area;
		this.address = address;
		this.pricePerYear = price;
		this.petsAllowed = pets;
		this.type = type;
		this.facilities = facilities;
		this.renter = null;
		this.status = RentStatus.rented;
	}

	/**
	 * 
	 * @param newPrice
	 */
	public void changePrice(double newPrice) {
		this.pricePerYear = newPrice;
	}

	/**
	 * 
	 * @param newFacility
	 */
	public void addFacility (Facility newFacility) {
		this.facilities.add(newFacility);
	}

	/**
	 * 
	 * @param aFacility
	 */
	public void removeFacility (Facility aFacility) {
		Iterator<Facility> itr = this.facilities.iterator(); 
        while (itr.hasNext()) { 
        	Facility f = (Facility)itr.next(); 
            if (f.equals(aFacility)) 
                itr.remove(); 
        } 
	}

	public boolean checkAvailability() {
		return (status==RentStatus.free);
	}

	/**
	 * 
	 * @param c
	 */
	public boolean rent(Customer c) {
		if (checkAvailability()) {
			renter=c;
			status = RentStatus.rented;
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * 
	 * @param c
	 */
	public boolean endRent(Customer c) {
		if ((renter!=null) && (renter.equals(c))) {
            renter = null;
            status = RentStatus.rented;
            return true;        
        }
		else
			return false;
	}

}