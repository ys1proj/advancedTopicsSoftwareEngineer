public class Room {

	roomType roomType;
	private int roomNumber;
	private double size;
	private double pricePerNight;
	private boolean isAvailable;
	private int houseID;
	private Customer renter;
	private RentStatus status;
	/**
	 * 
	 * @param customer
	 */
	public boolean rentRoomTo(Customer customer) {
		if (isAvailable()) {
			renter=customer;
			status = RentStatus.rented;
			return true;
		}
		else {
			return false;
		}
	}
	public Room(roomType roomType, int roomNumber, double size, double pricePerNight, boolean isAvailable, int houseID,
			Customer renter, RentStatus status) {
		super();
		this.roomType = roomType;
		this.roomNumber = roomNumber;
		this.size = size;
		this.pricePerNight = pricePerNight;
		this.isAvailable = isAvailable;
		this.houseID = houseID;
		this.renter = renter;
		this.status = status;
	}
	public roomType getRoomType() {
		return roomType;
	}
	public void setRoomType(roomType roomType) {
		this.roomType = roomType;
	}
	public int getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public double getPricePerNight() {
		return pricePerNight;
	}
	public void setPricePerNight(double pricePerNight) {
		this.pricePerNight = pricePerNight;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	public int getHouseID() {
		return houseID;
	}
	public void setHouseID(int houseID) {
		this.houseID = houseID;
	}
	public Customer getRenter() {
		return renter;
	}
	public void setRenter(Customer renter) {
		this.renter = renter;
	}
	public RentStatus getStatus() {
		return status;
	}
	public void setStatus(RentStatus status) {
		this.status = status;
	}

}