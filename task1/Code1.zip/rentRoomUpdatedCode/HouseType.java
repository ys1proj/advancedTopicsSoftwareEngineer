public enum HouseType {
	apartment,
	house,
	condo
}