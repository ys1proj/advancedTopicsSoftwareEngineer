public class Facility {

	private String name;
	private String description;
	private FacilityStatus status;

	public Facility (String name, String desc, FacilityStatus status) { 
        this.name=name;
        this.description=desc;
        this.status = status;
    } 
	
	public String getName() {
	    return this.name;
	}

	public void setName(String name) {
	     this.name = name;
	}
	
	public String getDescription() {
	    return this.description;
	}
	
	public void setDescription(String desc) {
	     this.description = desc;
	}
	
	public boolean equals (Facility f) {
		return (name == f.getName() && description == f.getDescription());
	}
	
	public FacilityStatus getStatus() {
	    return this.status;
	}
	
	public void setStatus(FacilityStatus s) {
	     this.status = s;
	}

}