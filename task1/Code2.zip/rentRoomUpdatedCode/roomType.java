public enum roomType {
	single,
	duo,
	family

}