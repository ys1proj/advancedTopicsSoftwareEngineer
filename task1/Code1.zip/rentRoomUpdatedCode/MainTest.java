import java.util.ArrayList;

public class MainTest {
		
	public static void main(String [ ] args) {
		Facility facility1 = new Facility ("Sofa", "2 seat sofa", FacilityStatus.asnew);
		Facility facility2 = new Facility ("Table", "140 cm table", FacilityStatus.good);
		Facility facility3 = new Facility ("Chair", "Black chair", FacilityStatus.good);
		Facility facility4 = new Facility ("Bed", "Double Bed", FacilityStatus.worn);
		Facility facility5 = new Facility ("Clock", "Alarm clock", FacilityStatus.asnew);
		
		ArrayList<Facility> facilities1 = new ArrayList <Facility>();
		facilities1.add(facility2);
		facilities1.add(facility4);
		facilities1.add(facility5);
		House house1 = new House (4, 3, 120, 0, "str 1, Haifa", 5000, true, HouseType.apartment, facilities1, null);
		
		ArrayList <Facility> facilities2 = new ArrayList <Facility>();
		facilities2.add(facility1);
		facilities2.add(facility3);
		facilities2.add(facility5);
		House house2 = new House (7, 8, 250, 0, "str 2, Tel Aviv", 10000, false, HouseType.house, facilities2, null);

		ArrayList <Customer> customers = new ArrayList<Customer>();
		for (int i=1; i<21; i++) {
			customers.add(new Customer("client"+i, "052"+(i*(i+1)*(i+2))));
		}
	    
		System.out.println("\n\n---- House 1 ----");
		for (int i=0; i<12; i++) {
			if (house1.rent(customers.get(i))) 
				System.out.println("The house is rented to " + customers.get(i).getName());
			else
				System.out.println("The house is full and can't be rented to " + customers.get(i).getName());
		}
		
		System.out.println("\n\n---- House 2 ----");
		for (int i=12; i<20; i++) {
			if (house2.rent(customers.get(i)))
				System.out.println("The house is rented to " + customers.get(i).getName());
			else
				System.out.println("The house is full and can't be rented to " + customers.get(i).getName());		}
		
		System.out.println("\n\n---- Return Houses ----");
		for (int i=19; i>=0; i--) {
			 if (house1.endRent(customers.get(i)))
				 System.out.println("House 1 was stopped rented by " + customers.get(i).getName());
			 else
				 System.out.println("House 1 was not rented to " + customers.get(i).getName());

			 if (house2.endRent(customers.get(i)))
				 System.out.println("House 2 was stopped rented by " + customers.get(i).getName());
			 else
				 System.out.println("House 2 was not rented to " + customers.get(i).getName());
		}
	}
}
